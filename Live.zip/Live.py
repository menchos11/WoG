def test_input(low, high, test):
    while True:
        try:
            if int(low) <= int(test) <= int(high):
                break
            else:
                test = input("difficult number must be in " + low + "-" + high + " range, please try again")
        except ValueError:
            test = input("please enter a number")


def welcome(name):
    print(f"hello", name, "and welcome to the World Of Games (WoG). \n"
                          "Here you can find many cool games to play.")
    return ""



def load_game():
    game = input("Please choose a game to play: "
                     "\n1. Memory Game - a sequence of numbers will appear for 1 second and you have to guess it back "
                     "\n2. Guess Game - guess a number and see if you chose like the computer "
                     "\n3. Currency Roulette - try and guess the value of a random amount of USD in ILS")
    test_input("1", "3", game)

    difficult = input("Please choose game difficulty from 1 to 5:")
    test_input("1", "5", difficult)

